#ifndef EEPROM_H
#define EEPROM_H

#include <avr/eeprom.h>
#include <stdint.h>
#include "config.h"

static inline void ee_load(int *hi1, int *hi2) {
    if (eeprom_read_byte((uint8_t *)EE_MAGIC) == MAGIC) {
        *hi1 = (int)eeprom_read_word((uint16_t *)EE_HI1);
        *hi2 = (int)eeprom_read_word((uint16_t *)EE_HI2);
        if (*hi1 < 0 || *hi1 > MAX_SCORE) *hi1 = 0;
        if (*hi2 < 0 || *hi2 > MAX_SCORE) *hi2 = 0;
    } else {
        eeprom_write_byte((uint8_t *)EE_MAGIC, MAGIC);
        eeprom_write_word((uint16_t *)EE_HI1, 0);
        eeprom_write_word((uint16_t *)EE_HI2, 0);
        *hi1 = *hi2 = 0;
    }
}

static inline void ee_save(int hi1, int hi2) {
    eeprom_update_word((uint16_t *)EE_HI1, (uint16_t)hi1);
    eeprom_update_word((uint16_t *)EE_HI2, (uint16_t)hi2);
}

static inline void ee_reset(int *hi1, int *hi2) {
    *hi1 = *hi2 = 0;
    ee_save(0, 0);
}

static inline void ee_check_and_save(int score1, int score2, int *hi1, int *hi2) {
    if (score1 > *hi1) *hi1 = score1;
    if (score2 > *hi2) *hi2 = score2;
    ee_save(*hi1, *hi2);
}

#endif
