#ifndef BUZZER_H
#define BUZZER_H

#include <stdint.h>

void buzz_update(void);
void beep_ok(void);
void beep_fail(void);
void beep_over(void);
void beep_click(void);
void beep_start(void);

#endif
