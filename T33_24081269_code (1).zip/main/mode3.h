#ifndef MODE3_H
#define MODE3_H

#include <stdint.h>

void    mode3_start(void);
uint8_t mode3_update(int *score1, int *score2);

#endif
