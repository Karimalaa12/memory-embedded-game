#ifndef MODE2_H
#define MODE2_H

#include <stdint.h>

void    mode2_start(void);
uint8_t mode2_update(int *score1, int *score2);

#endif
