#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include "config.h"
#include "lcd.h"
#include "game_common.h"
#include "input.h"
#include "buzzer.h"
#include "mode2.h"

#define M2_ANNOUNCE 0
#define M2_SHOWING  1
#define M2_PAUSE    2
#define M2_RACING   3
#define M2_RESULT   4
#define M2_BETWEEN  5
#define M2_DONE     6

static uint8_t  m2_st;
static int      m2_seq[SEQ_LEN_MAX], m2_len;
static int      m2_p1, m2_p2;
static int      m2_ok1, m2_ok2;
static uint8_t  m2_fin1, m2_fin2;
static uint32_t m2_end1, m2_end2;
static uint32_t m2_rstart, m2_t1, m2_t2;
static int      m2_i1, m2_i2;
static int8_t   m2_fb1, m2_fb2;
static uint32_t m2_fb1e, m2_fb2e;
static uint32_t m2_tmr, m2_dtmr;
static int      m2_round;
static uint8_t  m2_fl_started;

void mode2_start(void) {
    m2_st    = M2_ANNOUNCE;
    m2_p1    = m2_p2 = 0;
    m2_round = 0;
    m2_fb1   = m2_fb2 = -1;
}

uint8_t mode2_update(int *s1, int *s2) {
    uint32_t now = millis();

    if (m2_fb1 >= 0 && now >= m2_fb1e) { led_off((uint8_t)m2_fb1); m2_fb1 = -1; }
    if (m2_fb2 >= 0 && now >= m2_fb2e) { led_off((uint8_t)m2_fb2); m2_fb2 = -1; }

    switch (m2_st) {

    case M2_ANNOUNCE:
        m2_len = SEQ_LEN_START + m2_round;
        if (m2_len > SEQ_LEN_MAX) m2_len = SEQ_LEN_MAX;
        seq_make(m2_seq, m2_len);
        m2_i1 = m2_i2 = m2_ok1 = m2_ok2 = 0;
        m2_fin1 = m2_fin2 = 0;
        m2_end1 = m2_end2 = 0;
        m2_fb1 = m2_fb2 = -1;
        m2_fl_started = 0;
        { char t[17], b[17];
          snprintf(t, 17, "DUEL  Rnd %d/%d  ", m2_round + 1, DUEL_ROUNDS);
          snprintf(b, 17, "P1:%-3d  P2:%-3d ", m2_p1, m2_p2);
          lcd_row(0, t); lcd_row(1, b); }
        m2_tmr = now;
        m2_st  = M2_SHOWING;
        break;

    case M2_SHOWING:
        if ((uint32_t)(now - m2_tmr) < ANNOUNCE_MS) break;
        if (!m2_fl_started) {
            flash_start(m2_seq, m2_len, flash_ms(m2_round));
            m2_fl_started = 1;
        }
        if (flash_run()) { m2_tmr = now; m2_st = M2_PAUSE; }
        break;

    case M2_PAUSE:
        if ((uint32_t)(now - m2_tmr) >= INPUT_GAP) {
            m2_rstart = m2_t1 = m2_t2 = now;
            m2_dtmr   = now;
            input_clear_game();
            input_unlock_game();
            lcd_row(0, "GO! Both players");
            lcd_row(1, "P1:0     P2:0   ");
            m2_st = M2_RACING;
        }
        break;

    case M2_RACING: {
        int8_t b1 = m2_fin1 ? -1 : input_pop_p1();
        int8_t b2 = m2_fin2 ? -1 : input_pop_p2();
        if (m2_fin1) { while (input_pop_p1() >= 0) {} }
        if (m2_fin2) { while (input_pop_p2() >= 0) {} }

        if (b1 >= 0) {
            m2_t1 = now;
            led_on((uint8_t)b1); m2_fb1 = b1; m2_fb1e = now + 150UL;
            if (b1 == m2_seq[m2_i1]) {
                m2_i1++; m2_ok1++;
                if (m2_i1 >= m2_len) {
                    m2_fin1 = 1;
                    m2_end1 = (uint32_t)(now - m2_rstart);
                }
            } else {
                m2_fin1 = 1;
                m2_end1 = (uint32_t)(now - m2_rstart);
            }
        }

        if (b2 >= 0) {
            m2_t2 = now;
            led_on((uint8_t)b2); m2_fb2 = b2; m2_fb2e = now + 150UL;
            if (b2 == m2_seq[m2_i2]) {
                m2_i2++; m2_ok2++;
                if (m2_i2 >= m2_len) {
                    m2_fin2 = 1;
                    m2_end2 = (uint32_t)(now - m2_rstart);
                }
            } else {
                m2_fin2 = 1;
                m2_end2 = (uint32_t)(now - m2_rstart);
            }
        }

        if (!m2_fin1 && (uint32_t)(now - m2_t1) >= TIMEOUT_MS) {
            m2_fin1 = 1; m2_end1 = (uint32_t)(now - m2_rstart);
        }
        if (!m2_fin2 && (uint32_t)(now - m2_t2) >= TIMEOUT_MS) {
            m2_fin2 = 1; m2_end2 = (uint32_t)(now - m2_rstart);
        }

        if ((uint32_t)(now - m2_dtmr) >= 300UL) {
            m2_dtmr = now;
            char b[17];
            snprintf(b, 17, "P1:%-3d   P2:%-3d ", m2_ok1, m2_ok2);
            lcd_row(1, b);
        }

        if (m2_fin1 && m2_fin2) {
            input_lock_game();
            m2_tmr = now;
            m2_st  = M2_RESULT;
        }
        break;
    }

    case M2_RESULT: {
        leds_off();
        int mult = 1 + m2_round / DIFF_EVERY;
        m2_p1 += m2_ok1 * DUEL_PTS * mult;
        m2_p2 += m2_ok2 * DUEL_PTS * mult;

        uint8_t rw = 2;
        if      (m2_ok1 > m2_ok2)                              { rw = 0; }
        else if (m2_ok2 > m2_ok1)                              { rw = 1; }
        else if (m2_ok1 == m2_len && m2_ok2 == m2_len) {
            rw = (m2_end1 <= m2_end2) ? 0u : 1u;
        }

        if      (rw == 0) { m2_p1 += DUEL_SPEED * mult; lcd_row(0, ">> P1 WINS!    "); }
        else if (rw == 1) { m2_p2 += DUEL_SPEED * mult; lcd_row(0, ">> P2 WINS!    "); }
        else              {                               lcd_row(0, "   DRAW!       "); }

        if (m2_p1 > MAX_SCORE) m2_p1 = MAX_SCORE;
        if (m2_p2 > MAX_SCORE) m2_p2 = MAX_SCORE;

        { char b[17];
          snprintf(b, 17, "P1:%-3d  P2:%-3d ", m2_p1, m2_p2);
          lcd_row(1, b); }
        beep_start();
        m2_round++;
        m2_tmr = now;
        m2_st  = M2_BETWEEN;
        break;
    }

    case M2_BETWEEN:
        if ((uint32_t)(now - m2_tmr) >= RESULT_MS)
            m2_st = (m2_round >= DUEL_ROUNDS) ? M2_DONE : M2_ANNOUNCE;
        break;

    case M2_DONE:
        leds_off();
        *s1 = m2_p1; *s2 = m2_p2;
        return 1;
    }

    return 0;
}
