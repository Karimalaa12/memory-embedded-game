#include <avr/io.h>
#include <util/delay.h>
#include <stdint.h>
#include <string.h>
#include "lcd.h"
#include "config.h"

#define RS  0x01
#define EN  0x04
#define BL  0x08

static uint8_t backlight = BL;

static void twi_wait(void) {
    while (!(TWCR & (1 << TWINT)));
}

static void i2c_send(uint8_t data) {
    TWCR = (1<<TWINT)|(1<<TWSTA)|(1<<TWEN);
    twi_wait();
    TWDR = (LCD_ADDR << 1) | 0x00;
    TWCR = (1<<TWINT)|(1<<TWEN);
    twi_wait();
    TWDR = data;
    TWCR = (1<<TWINT)|(1<<TWEN);
    twi_wait();
    TWCR = (1<<TWINT)|(1<<TWSTO)|(1<<TWEN);
    while (TWCR & (1<<TWSTO));
}

static void pulse_en(uint8_t val) {
    i2c_send(val | EN);
    _delay_us(1);
    i2c_send(val & ~EN);
    _delay_us(50);
}

static void send_nibble(uint8_t nibble, uint8_t rs) {
    uint8_t v = (uint8_t)((nibble & 0x0F) << 4) | backlight | (rs ? RS : 0);
    pulse_en(v);
}

static void send_byte(uint8_t byte, uint8_t rs) {
    send_nibble(byte >> 4,   rs);
    send_nibble(byte & 0x0F, rs);
}

static void lcd_cmd(uint8_t cmd) { send_byte(cmd, 0); }

void lcd_init(void) {
    TWBR = 72;
    TWSR = 0x00;
    TWCR = (1<<TWEN);
    backlight = BL;
    _delay_ms(100);
    send_nibble(0x03, 0); _delay_ms(5);
    send_nibble(0x03, 0); _delay_us(200);
    send_nibble(0x03, 0); _delay_us(200);
    send_nibble(0x02, 0); _delay_us(200);
    lcd_cmd(0x28); _delay_us(60);
    lcd_cmd(0x0C); _delay_us(60);
    lcd_cmd(0x06); _delay_us(60);
    lcd_cmd(0x01); _delay_ms(3);
}

void lcd_backlight(uint8_t on) {
    backlight = on ? BL : 0;
    i2c_send(backlight);
}

void lcd_goto(uint8_t col, uint8_t row) {
    uint8_t addr = (row == 0) ? col : (uint8_t)(0x40 + col);
    lcd_cmd((uint8_t)(0x80 | addr));
}

void lcd_char(char c) {
    send_byte((uint8_t)c, 1);
}

void lcd_str(const char *s) {
    while (*s) lcd_char(*s++);
}

void lcd_num(uint16_t n, uint8_t width) {
    char buf[6];
    uint8_t i = 0;
    if (n == 0) buf[i++] = '0';
    while (n > 0) { buf[i++] = (char)('0' + n % 10); n /= 10; }
    while (i < width) buf[i++] = ' ';
    for (int8_t j = (int8_t)(i-1); j >= 0; j--) lcd_char(buf[j]);
}

void lcd_row(uint8_t row, const char *text) {
    lcd_goto(0, row);
    uint8_t n = 0;
    while (text[n] && n < 16) { lcd_char(text[n]); n++; }
    while (n < 16) { lcd_char(' '); n++; }
}

void lcd_custom(uint8_t idx, const uint8_t *bmp) {
    lcd_cmd((uint8_t)(0x40 | ((idx & 0x07) << 3)));
    for (uint8_t i = 0; i < 8; i++) send_byte(bmp[i], 1);
    lcd_goto(0, 0);
}

void lcd_write_custom(uint8_t idx) {
    lcd_char((char)(idx & 0x07));
}
