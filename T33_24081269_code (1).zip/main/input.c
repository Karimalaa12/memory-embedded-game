#include <avr/interrupt.h>
#include <stdint.h>
#include "input.h"
#include "config.h"

BtnQueue q_p1 = {{0}, 0, 0};
BtnQueue q_p2 = {{0}, 0, 0};

volatile int8_t  nav_press  = -1;
volatile uint8_t input_lock = 1;
volatile uint8_t nav_lock   = 1;

void input_clear_game(void) {
    uint8_t sreg = SREG;
    cli();
    q_p1.head = q_p1.tail = 0;
    q_p2.head = q_p2.tail = 0;
    SREG = sreg;
}

void input_clear_nav(void) {
    uint8_t sreg = SREG;
    cli();
    nav_press = -1;
    SREG = sreg;
}

void input_clear_all(void) {
    input_clear_game();
    input_clear_nav();
}

int8_t input_pop_p1(void) {
    if (q_p1.head == q_p1.tail) return -1;
    uint8_t b = q_p1.buf[q_p1.head];
    q_p1.head = (uint8_t)((q_p1.head + 1u) & BTN_QUEUE_MASK);
    return (int8_t)b;
}

int8_t input_pop_p2(void) {
    if (q_p2.head == q_p2.tail) return -1;
    uint8_t b = q_p2.buf[q_p2.head];
    q_p2.head = (uint8_t)((q_p2.head + 1u) & BTN_QUEUE_MASK);
    return (int8_t)b;
}

int8_t input_pop_nav(void) {
    int8_t b;
    uint8_t sreg = SREG;
    cli();
    b = nav_press;
    if (b >= 0) nav_press = -1;
    SREG = sreg;
    return b;
}
