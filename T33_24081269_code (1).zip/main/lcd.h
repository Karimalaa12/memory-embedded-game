#ifndef LCD_H
#define LCD_H

#include <stdint.h>

void lcd_init(void);
void lcd_backlight(uint8_t on);
void lcd_goto(uint8_t col, uint8_t row);
void lcd_char(char c);
void lcd_str(const char *s);
void lcd_num(uint16_t n, uint8_t width);
void lcd_row(uint8_t row, const char *text);
void lcd_custom(uint8_t idx, const uint8_t *bmp);
void lcd_write_custom(uint8_t idx);

#endif
