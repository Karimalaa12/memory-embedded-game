#ifndef GAME_COMMON_H
#define GAME_COMMON_H

#include <stdint.h>
#include "config.h"

extern volatile uint32_t ms_count;
uint32_t millis(void);

void led_on(uint8_t idx);
void led_off(uint8_t idx);
void leds_off(void);

void seq_make(int *seq, int len);

void    flash_start(int *seq, int len, int on_ms);
uint8_t flash_run(void);
int     flash_ms(int round);

#endif
