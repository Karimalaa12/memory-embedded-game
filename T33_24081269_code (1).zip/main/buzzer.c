#include <avr/io.h>
#include <stdint.h>
#include "buzzer.h"
#include "config.h"
#include "game_common.h"

static uint32_t buzz_start_ms = 0;
static uint16_t buzz_dur_ms   = 0;
static uint8_t  buzz_active   = 0;

static void beep(uint8_t ocr, uint16_t dur_ms) {
    TCCR2B = 0;
    TCNT2  = 0;
    TCCR2A = (1<<COM2A0) | (1<<WGM21);
    OCR2A  = ocr;
    TCCR2B = (1<<CS22) | (1<<CS21);
    buzz_start_ms = millis();
    buzz_dur_ms   = dur_ms;
    buzz_active   = 1;
}

void buzz_update(void) {
    if (!buzz_active) return;
    if ((uint32_t)(millis() - buzz_start_ms) >= (uint32_t)buzz_dur_ms) {
        TCCR2B = 0;
        TCCR2A = 0;
        PORTB &= (uint8_t)~(1 << BUZZ_BIT);
        buzz_active = 0;
    }
}

void beep_ok(void)    { beep(BUZZ_OK,   DUR_SHORT);      }
void beep_fail(void)  { beep(BUZZ_FAIL, DUR_LONG);       }
void beep_over(void)  { beep(BUZZ_OVER, DUR_LONG * 2u);  }
void beep_click(void) { beep(BUZZ_CLICK, DUR_SHORT / 2u);}
void beep_start(void) { beep(BUZZ_START, DUR_LONG);      }
