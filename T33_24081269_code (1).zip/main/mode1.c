#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include "config.h"
#include "lcd.h"
#include "game_common.h"
#include "input.h"
#include "buzzer.h"
#include "mode1.h"

#define M1_ANNOUNCE 0
#define M1_SHOWING  1
#define M1_PAUSE    2
#define M1_INPUT    3
#define M1_WIN      4
#define M1_FAIL     5
#define M1_DONE     6

static uint8_t  m1_st;
static int      m1_seq[SEQ_LEN_MAX];
static int      m1_len, m1_idx, m1_score, m1_round;
static uint32_t m1_tmr, m1_btmr;
static int8_t   m1_fb;
static uint32_t m1_fbe;

void mode1_start(void) {
    m1_st    = M1_ANNOUNCE;
    m1_len   = SEQ_LEN_START;
    m1_score = 0;
    m1_round = 0;
    m1_fb    = -1;
    seq_make(m1_seq, SEQ_LEN_MAX);
    lcd_row(0, " SOLO  SPRINT  ");
    lcd_row(1, " Watch & Copy  ");
    m1_tmr = millis();
}

uint8_t mode1_update(int *score_out) {
    uint32_t now = millis();

    if (m1_fb >= 0 && now >= m1_fbe) { led_off((uint8_t)m1_fb); m1_fb = -1; }

    switch (m1_st) {

    case M1_ANNOUNCE:
        if ((uint32_t)(now - m1_tmr) >= ANNOUNCE_MS) {
            flash_start(m1_seq, m1_len, flash_ms(m1_round));
            m1_st = M1_SHOWING;
        }
        break;

    case M1_SHOWING:
        if (flash_run()) {
            m1_tmr = now;
            m1_st  = M1_PAUSE;
        }
        break;

    case M1_PAUSE:
        if ((uint32_t)(now - m1_tmr) >= INPUT_GAP) {
            m1_idx  = 0;
            m1_btmr = now;
            input_clear_game();
            input_unlock_game();
            { char b[17];
              snprintf(b, 17, "P1: Seq len %-2d  ", m1_len);
              lcd_row(0, b);
              lcd_row(1, " YOUR TURN! P1 "); }
            m1_st = M1_INPUT;
        }
        break;

    case M1_INPUT: {
        if ((uint32_t)(now - m1_btmr) >= TIMEOUT_MS) {
            input_lock_game();
            beep_over();
            { char b[17];
              snprintf(b, 17, " Score:%-3d      ", m1_score);
              lcd_row(0, " TIME OUT!     ");
              lcd_row(1, b); }
            m1_tmr = now;
            m1_st  = M1_FAIL;
            break;
        }

        int8_t btn = input_pop_p1();
        if (btn >= 0) {
            m1_btmr = now;
            led_on((uint8_t)btn);
            m1_fb  = btn;
            m1_fbe = now + 200UL;

            if (btn == m1_seq[m1_idx]) {
                beep_ok();
                m1_idx++;
                if (m1_idx >= m1_len) {
                    input_lock_game();
                    int mult = 1 + m1_round / DIFF_EVERY;
                    m1_score += SOLO_PTS * mult;
                    if (m1_score > MAX_SCORE) m1_score = MAX_SCORE;
                    m1_round++;
                    m1_len++;
                    if (m1_len > SEQ_LEN_MAX) m1_len = SEQ_LEN_MAX;
                    { char b[17];
                      snprintf(b, 17, " Score:%-3d      ", m1_score);
                      lcd_row(0, "  CORRECT!     ");
                      lcd_row(1, b); }
                    beep_start();
                    m1_tmr = now;
                    m1_st  = M1_WIN;
                }
            } else {
                input_lock_game();
                beep_fail();
                { char b[17];
                  snprintf(b, 17, " Score:%-3d      ", m1_score);
                  lcd_row(0, " WRONG! :(     ");
                  lcd_row(1, b); }
                m1_tmr = now;
                m1_st  = M1_FAIL;
            }
        }
        break;
    }

    case M1_WIN:
        if ((uint32_t)(now - m1_tmr) >= RESULT_MS) {
            { char b[17];
              snprintf(b, 17, " SOLO  Seq:%-2d  ", m1_len);
              lcd_row(0, b);
              lcd_row(1, " Get Ready...  "); }
            m1_tmr = now;
            m1_st  = M1_ANNOUNCE;
        }
        break;

    case M1_FAIL:
        if ((uint32_t)(now - m1_tmr) >= RESULT_MS) m1_st = M1_DONE;
        break;

    case M1_DONE:
        leds_off();
        *score_out = m1_score;
        return 1;
    }

    return 0;
}
