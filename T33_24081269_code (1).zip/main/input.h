#ifndef INPUT_H
#define INPUT_H

#include <stdint.h>
#include "config.h"

typedef struct {
    volatile uint8_t buf[BTN_QUEUE_SIZE];
    volatile uint8_t head;
    volatile uint8_t tail;
} BtnQueue;

extern BtnQueue q_p1;
extern BtnQueue q_p2;
extern volatile int8_t  nav_press;
extern volatile uint8_t input_lock;
extern volatile uint8_t nav_lock;

static inline void input_lock_all(void)    { input_lock = 1; nav_lock = 1; }
static inline void input_unlock_game(void) { input_lock = 0; }
static inline void input_lock_game(void)   { input_lock = 1; }
static inline void input_unlock_nav(void)  { nav_lock = 0; }
static inline void input_lock_nav(void)    { nav_lock = 1; }

void input_clear_game(void);
void input_clear_nav(void);
void input_clear_all(void);

int8_t input_pop_p1(void);
int8_t input_pop_p2(void);
int8_t input_pop_nav(void);

static inline void input_push_p1(uint8_t btn) {
    uint8_t next = (uint8_t)((q_p1.tail + 1u) & BTN_QUEUE_MASK);
    if (next != q_p1.head) {
        q_p1.buf[q_p1.tail] = btn;
        q_p1.tail = next;
    }
}

static inline void input_push_p2(uint8_t btn) {
    uint8_t next = (uint8_t)((q_p2.tail + 1u) & BTN_QUEUE_MASK);
    if (next != q_p2.head) {
        q_p2.buf[q_p2.tail] = btn;
        q_p2.tail = next;
    }
}

#endif
