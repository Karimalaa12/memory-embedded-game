#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/sleep.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "config.h"
#include "lcd.h"
#include "input.h"
#include "game_common.h"
#include "buzzer.h"
#include "eeprom.h"
#include "mode1.h"
#include "mode2.h"
#include "mode3.h"

volatile uint32_t ms_count = 0;

static volatile uint32_t last_active = 0;
static          uint8_t  sleeping    = 0;

static int hi1 = 0;
static int hi2 = 0;

static uint8_t app_state = APP_SPLASH;
static uint8_t menu_sel  = 0;

static int p1_score = 0, p2_score = 0;

static uint8_t  reset_confirm = 0;
static uint32_t reset_tmr     = 0;

static uint32_t wait_tmr   = 0;
static uint32_t wait_dur   = 0;
static uint8_t  post_state = APP_MENU;

static uint32_t splash_tmr = 0;

static void init_timer1(void) {
    TCCR1A = 0;
    TCCR1B = (1 << WGM12);
    OCR1A  = 249;
    TIMSK1 = (1 << OCIE1A);
    TCCR1B |= (1 << CS11) | (1 << CS10);
}

ISR(TIMER1_COMPA_vect) {
    ms_count++;
}

static volatile uint8_t  p1_last[4]    = {1, 1, 1, 1};
static volatile uint8_t  p2_last[4]    = {1, 1, 1, 1};
static volatile uint8_t  nav_last[2]   = {1, 1};
static volatile uint8_t  nav_rdy[2]    = {1, 1};

static volatile uint32_t t_p1[4]       = {0, 0, 0, 0};
static volatile uint32_t t_p2[4]       = {0, 0, 0, 0};
static volatile uint32_t t_nav[2]      = {0, 0};

static inline uint8_t check_game_btn(uint8_t cur_low,
                                     volatile uint8_t *last,
                                     volatile uint32_t *tmr,
                                     uint32_t now)
{
    if (cur_low) {
        if (*last == 1) {
            if ((uint32_t)(now - *tmr) >= DEBOUNCE_MS) {
                *tmr  = now;
                *last = 0;
                return 1;
            }
        }
    } else {
        *last = 1;
    }
    return 0;
}

static inline uint8_t check_nav_btn(uint8_t cur_low,
                                    volatile uint8_t *last,
                                    volatile uint8_t *rdy,
                                    volatile uint32_t *tmr,
                                    uint32_t now)
{
    if (cur_low) {
        if (*last == 1 && *rdy == 1) {
            if ((uint32_t)(now - *tmr) >= DEBOUNCE_MS) {
                *tmr  = now;
                *last = 0;
                *rdy  = 0;
                return 1;
            }
        } else if (*last == 1) {
            *last = 0;
        }
    } else {
        *last = 1;
        *rdy  = 1;
    }
    return 0;
}

static void init_pcint(void) {
    DDRD  &= (uint8_t)~((1<<BTN_P1_0_BIT)|(1<<BTN_P1_1_BIT)
                       |(1<<BTN_P1_2_BIT)|(1<<BTN_P1_3_BIT));
    PORTD |=  (1<<BTN_P1_0_BIT)|(1<<BTN_P1_1_BIT)
             |(1<<BTN_P1_2_BIT)|(1<<BTN_P1_3_BIT);

    DDRD  &= (uint8_t)~((1<<BTN_P2_0_BIT)|(1<<BTN_P2_1_BIT));
    PORTD |=  (1<<BTN_P2_0_BIT)|(1<<BTN_P2_1_BIT);

    DDRB  &= (uint8_t)~((1<<BTN_P2_2_BIT)|(1<<BTN_P2_3_BIT));
    PORTB |=  (1<<BTN_P2_2_BIT)|(1<<BTN_P2_3_BIT);

    DDRC  &= (uint8_t)~((1<<BTN_NAV_UP_BIT)|(1<<BTN_NAV_SEL_BIT));
    PORTC |=  (1<<BTN_NAV_UP_BIT)|(1<<BTN_NAV_SEL_BIT);

    PCICR |= (1<<PCIE0)|(1<<PCIE1)|(1<<PCIE2);

    PCMSK0 |= (1<<BTN_P2_2_BIT)|(1<<BTN_P2_3_BIT);
    PCMSK1 |= (1<<BTN_NAV_UP_BIT)|(1<<BTN_NAV_SEL_BIT);
    PCMSK2 |= (1<<BTN_P1_0_BIT)|(1<<BTN_P1_1_BIT)
             |(1<<BTN_P1_2_BIT)|(1<<BTN_P1_3_BIT)
             |(1<<BTN_P2_0_BIT)|(1<<BTN_P2_1_BIT);
}

ISR(PCINT0_vect) {
    uint32_t now = ms_count;
    last_active = now;
    if (sleeping) { sleeping = 0; return; }

    if (!input_lock) {
        if (check_game_btn(!(PINB & (1<<BTN_P2_2_BIT)), &p2_last[2], &t_p2[2], now))
            input_push_p2(2);
        if (check_game_btn(!(PINB & (1<<BTN_P2_3_BIT)), &p2_last[3], &t_p2[3], now))
            input_push_p2(3);
    } else {
        uint8_t cur2 = !(PINB & (1<<BTN_P2_2_BIT));
        uint8_t cur3 = !(PINB & (1<<BTN_P2_3_BIT));
        if (!cur2) p2_last[2] = 1;
        if (!cur3) p2_last[3] = 1;
    }
}

ISR(PCINT1_vect) {
    uint32_t now = ms_count;
    last_active = now;
    if (sleeping) { sleeping = 0; return; }

    uint8_t cur0 = !(PINC & (1<<BTN_NAV_UP_BIT));
    uint8_t cur1 = !(PINC & (1<<BTN_NAV_SEL_BIT));

    if (!nav_lock) {
        if (check_nav_btn(cur0, &nav_last[0], &nav_rdy[0], &t_nav[0], now))
            nav_press = 0;
        if (check_nav_btn(cur1, &nav_last[1], &nav_rdy[1], &t_nav[1], now))
            nav_press = 1;
    } else {
        if (!cur0) { nav_last[0] = 1; nav_rdy[0] = 1; }
        if (!cur1) { nav_last[1] = 1; nav_rdy[1] = 1; }
    }
}

ISR(PCINT2_vect) {
    uint32_t now = ms_count;
    last_active = now;
    if (sleeping) { sleeping = 0; return; }

    uint8_t c0 = !(PIND & (1<<BTN_P1_0_BIT));
    uint8_t c1 = !(PIND & (1<<BTN_P1_1_BIT));
    uint8_t c2 = !(PIND & (1<<BTN_P1_2_BIT));
    uint8_t c3 = !(PIND & (1<<BTN_P1_3_BIT));
    uint8_t d0 = !(PIND & (1<<BTN_P2_0_BIT));
    uint8_t d1 = !(PIND & (1<<BTN_P2_1_BIT));

    if (!input_lock) {
        if (check_game_btn(c0, &p1_last[0], &t_p1[0], now)) input_push_p1(0);
        if (check_game_btn(c1, &p1_last[1], &t_p1[1], now)) input_push_p1(1);
        if (check_game_btn(c2, &p1_last[2], &t_p1[2], now)) input_push_p1(2);
        if (check_game_btn(c3, &p1_last[3], &t_p1[3], now)) input_push_p1(3);
        if (check_game_btn(d0, &p2_last[0], &t_p2[0], now)) input_push_p2(0);
        if (check_game_btn(d1, &p2_last[1], &t_p2[1], now)) input_push_p2(1);
    } else {
        if (!c0) p1_last[0] = 1;
        if (!c1) p1_last[1] = 1;
        if (!c2) p1_last[2] = 1;
        if (!c3) p1_last[3] = 1;
        if (!d0) p2_last[0] = 1;
        if (!d1) p2_last[1] = 1;
    }
}

static void init_outputs(void) {
    DDRC  |= (1<<LED0_BIT)|(1<<LED1_BIT);
    PORTC &= (uint8_t)~((1<<LED0_BIT)|(1<<LED1_BIT));
    DDRB  |= (1<<LED2_BIT)|(1<<LED3_BIT);
    PORTB &= (uint8_t)~((1<<LED2_BIT)|(1<<LED3_BIT));
    DDRB  |= (1<<BUZZ_BIT);
    PORTB &= (uint8_t)~(1<<BUZZ_BIT);
}

static void enter_sleep(void) {
    leds_off();
    lcd_backlight(0);
    sleeping = 1;
    set_sleep_mode(SLEEP_MODE_PWR_DOWN);
    sleep_enable();
    sei();
    sleep_cpu();
    sleep_disable();
    lcd_backlight(1);
}

static void seed_rng(void) {
    ADMUX  = (1<<REFS0) | 3;
    ADCSRA = (1<<ADEN)|(1<<ADSC)|(1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0);
    while (ADCSRA & (1<<ADSC));
    uint16_t seed = ADC;
    ADCSRA |= (1<<ADSC);
    while (ADCSRA & (1<<ADSC));
    seed ^= (uint16_t)(ADC << 5);
    ADCSRA = 0;
    srand(seed);
}

static void load_custom_chars(void) {
    static const uint8_t ARROW[8] = {0x00,0x08,0x0C,0x0E,0x0C,0x08,0x00,0x00};
    static const uint8_t STAR[8]  = {0x00,0x04,0x15,0x0E,0x1F,0x0E,0x15,0x04};
    static const uint8_t HEART[8] = {0x00,0x0A,0x1F,0x1F,0x0E,0x04,0x00,0x00};
    static const uint8_t NOTE[8]  = {0x04,0x0E,0x0E,0x0E,0x1F,0x00,0x04,0x00};
    lcd_custom(0, ARROW);
    lcd_custom(1, STAR);
    lcd_custom(2, HEART);
    lcd_custom(3, NOTE);
}

static const char *MENU_NAMES[MENU_COUNT] = {
    "1. SOLO SPRINT",
    "2. SYNC DUEL  ",
    "3. CHALLENGER ",
    "4. HIGH SCORES"
};
static const char *MENU_HINT[MENU_COUNT] = {
    "Memory+Speed    ",
    "2-Player Race   ",
    "Set & Replicate ",
    "View/Reset Best "
};

static void show_menu(void) {
    uint8_t nxt = (uint8_t)((menu_sel + 1) % MENU_COUNT);
    lcd_goto(0, 0);
    lcd_write_custom(0);
    lcd_str(MENU_NAMES[menu_sel]);
    uint8_t used = (uint8_t)(strlen(MENU_NAMES[menu_sel]) + 1);
    while (used < 16) { lcd_char(' '); used++; }
    lcd_goto(0, 1);
    lcd_char(' ');
    lcd_str(MENU_HINT[nxt]);
}

static void show_winner(int s1, int s2) {
    if (s1 > s2) {
        lcd_goto(0, 0);
        lcd_write_custom(1); lcd_str(" P1  WINS!    "); lcd_write_custom(1);
        lcd_row(1, " Well done P1! ");
    } else if (s2 > s1) {
        lcd_goto(0, 0);
        lcd_write_custom(1); lcd_str(" P2  WINS!    "); lcd_write_custom(1);
        lcd_row(1, " Well done P2! ");
    } else {
        lcd_row(0, "  IT'S A DRAW! ");
        lcd_row(1, " Both get pts! ");
    }
}

static void enter_wait(uint32_t dur, uint8_t next) {
    input_lock_all();
    wait_tmr   = ms_count;
    wait_dur   = dur;
    post_state = next;
    app_state  = APP_WAIT;
}

int main(void) {
    seed_rng();
    init_timer1();
    init_outputs();
    init_pcint();
    lcd_init();
    load_custom_chars();
    ee_load(&hi1, &hi2);
    sei();

    lcd_goto(0, 0); lcd_write_custom(1); lcd_str(" MEMORY GAME  "); lcd_write_custom(1);
    lcd_goto(0, 1); lcd_write_custom(3); lcd_str("  v2.0 FIXED  "); lcd_write_custom(3);
    splash_tmr = ms_count;
    app_state  = APP_SPLASH;

    while (1) {

        buzz_update();

        if (!sleeping && (uint32_t)(ms_count - last_active) >= SLEEP_MS) {
            enter_sleep();
            app_state    = APP_MENU;
            menu_sel     = 0;
            reset_confirm = 0;
            p1_score = p2_score = 0;
            input_clear_all();
            input_unlock_nav();
            show_menu();
            continue;
        }

        switch (app_state) {

        case APP_SPLASH:
            if ((uint32_t)(ms_count - splash_tmr) >= SPLASH_MS) {
                input_clear_all();
                input_unlock_nav();
                app_state = APP_MENU;
                show_menu();
                last_active = ms_count;
            }
            break;

        case APP_MENU: {
            int8_t nav = input_pop_nav();

            if (nav == 0) {
                menu_sel = (uint8_t)((menu_sel + 1) % MENU_COUNT);
                beep_click();
                show_menu();
            } else if (nav == 1) {
                beep_start();
                p1_score = p2_score = 0;
                input_lock_all();
                input_clear_all();

                switch (menu_sel) {
                    case MENU_SOLO:
                        mode1_start();
                        app_state = APP_SOLO;
                        break;
                    case MENU_DUEL:
                        mode2_start();
                        app_state = APP_DUEL;
                        break;
                    case MENU_CHALL:
                        mode3_start();
                        app_state = APP_CHALL;
                        break;
                    case MENU_SCORES:
                        reset_confirm = 0;
                        lcd_goto(0, 0);
                        lcd_write_custom(2); lcd_str(" BEST SCORES "); lcd_write_custom(2);
                        lcd_goto(0, 1);
                        lcd_str("P1:"); lcd_num((uint16_t)hi1, 3);
                        lcd_str("  P2:"); lcd_num((uint16_t)hi2, 3);
                        app_state = APP_SCORES;
                        break;
                }
            }
            break;
        }

        case APP_SOLO:
            if (mode1_update(&p1_score)) {
                ee_check_and_save(p1_score, 0, &hi1, &hi2);
                { char b[17];
                  snprintf(b, 17, "P1 Score: %-4d  ", p1_score);
                  lcd_row(0, " GAME  OVER!   ");
                  lcd_row(1, b); }
                enter_wait(GAMEOVER_MS, APP_MENU);
            }
            break;

        case APP_DUEL:
            if (mode2_update(&p1_score, &p2_score)) {
                ee_check_and_save(p1_score, p2_score, &hi1, &hi2);
                show_winner(p1_score, p2_score);
                enter_wait(GAMEOVER_MS, APP_MENU);
            }
            break;

        case APP_CHALL:
            if (mode3_update(&p1_score, &p2_score)) {
                ee_check_and_save(p1_score, p2_score, &hi1, &hi2);
                show_winner(p1_score, p2_score);
                enter_wait(GAMEOVER_MS, APP_MENU);
            }
            break;

        case APP_WAIT:
            if ((uint32_t)(ms_count - wait_tmr) >= wait_dur) {
                input_clear_all();
                input_unlock_nav();
                app_state = post_state;
                if (post_state == APP_MENU) show_menu();
            }
            break;

        case APP_SCORES: {
            int8_t nav = input_pop_nav();

            if (!reset_confirm) {
                if (nav == 0) {
                    reset_confirm = 1;
                    reset_tmr = ms_count;
                    lcd_row(0, "Reset scores?  ");
                    lcd_row(1, "SEL=Yes  UP=No ");
                } else if (nav == 1) {
                    input_clear_all();
                    app_state = APP_MENU;
                    show_menu();
                }
            } else {
                if (nav == 1) {
                    ee_reset(&hi1, &hi2);
                    beep_ok();
                    lcd_row(0, "Scores cleared!");
                    lcd_row(1, "                ");
                    reset_confirm = 0;
                    enter_wait(SCORES_CLEAR_MS, APP_SCORES);
                    post_state = APP_MENU;
                } else if (nav == 0 || (uint32_t)(ms_count - reset_tmr) >= 5000UL) {
                    reset_confirm = 0;
                    lcd_goto(0, 0);
                    lcd_write_custom(2); lcd_str(" BEST SCORES "); lcd_write_custom(2);
                    lcd_goto(0, 1);
                    lcd_str("P1:"); lcd_num((uint16_t)hi1, 3);
                    lcd_str("  P2:"); lcd_num((uint16_t)hi2, 3);
                }
            }
            break;
        }

        default:
            input_clear_all();
            input_unlock_nav();
            app_state = APP_MENU;
            show_menu();
            break;

        }
    }

    return 0;
}
