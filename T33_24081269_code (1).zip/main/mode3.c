#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include "config.h"
#include "lcd.h"
#include "game_common.h"
#include "input.h"
#include "buzzer.h"
#include "mode3.h"

#define M3_ANNOUNCE    0
#define M3_SET_SEQ     1
#define M3_SHOW_SEQ    2
#define M3_PAUSE       3
#define M3_REPLICATE   4
#define M3_CHECK       5
#define M3_PROVE_START 6
#define M3_PROVING     7
#define M3_CHECK_PROVE 8
#define M3_ROUND_END   9
#define M3_DONE       10

static uint8_t  m3_st;
static int      m3_secret[CHALL_SEQ_MAX];
static int      m3_sec_len;
static int      m3_p1, m3_p2, m3_round, m3_chall;
static int      m3_rep_idx;
static uint8_t  m3_rep_ok;
static int8_t   m3_fb;
static uint32_t m3_fbe, m3_tmr, m3_btmr;
static int      m3_entry_len;
static uint8_t  m3_fl_started;
static int      m3_last_elen;

static int8_t chall_btn(void) {
    return (m3_chall == 0) ? input_pop_p1() : input_pop_p2();
}
static int8_t rep_btn(void) {
    return (m3_chall == 0) ? input_pop_p2() : input_pop_p1();
}
static void give_pts(int who, int pts) {
    if (who == 0) { m3_p1 += pts; if (m3_p1 > MAX_SCORE) m3_p1 = MAX_SCORE; }
    else          { m3_p2 += pts; if (m3_p2 > MAX_SCORE) m3_p2 = MAX_SCORE; }
}

void mode3_start(void) {
    m3_st         = M3_ANNOUNCE;
    m3_p1         = m3_p2 = 0;
    m3_round      = 0;
    m3_chall      = 0;
    m3_fb         = -1;
    m3_last_elen  = -1;
}

uint8_t mode3_update(int *s1, int *s2) {
    uint32_t now = millis();

    if (m3_fb >= 0 && now >= m3_fbe) { led_off((uint8_t)m3_fb); m3_fb = -1; }

    switch (m3_st) {

    case M3_ANNOUNCE: {
        char t[17], b[17];
        snprintf(t, 17, "CHALLENGE Rnd %d", m3_round + 1);
        snprintf(b, 17, "P%d sets secret ", m3_chall + 1);
        lcd_row(0, t); lcd_row(1, b);
        m3_entry_len  = 0;
        m3_rep_ok     = 0;
        m3_fl_started = 0;
        m3_last_elen  = -1;
        m3_tmr = now;
        input_clear_all();
        input_unlock_game();
        input_unlock_nav();
        m3_st = M3_SET_SEQ;
        break;
    }

    case M3_SET_SEQ: {
        if ((uint32_t)(now - m3_tmr) < ANNOUNCE_MS) break;

        if (m3_entry_len != m3_last_elen) {
            char t[17], b[17];
            snprintf(t, 17, "P%d btn=LED clr", m3_chall + 1);
            snprintf(b, 17, "Len:%d/%d UP=undo", m3_entry_len, CHALL_SEQ_MAX);
            lcd_row(0, t); lcd_row(1, b);
            m3_last_elen = m3_entry_len;
        }

        int8_t btn = chall_btn();
        if (btn >= 0 && m3_entry_len < CHALL_SEQ_MAX) {
            m3_secret[m3_entry_len++] = btn;
            led_on((uint8_t)btn);
            m3_fb  = btn;
            m3_fbe = now + 300UL;
            beep_ok();
            m3_last_elen = -1;
        }

        int8_t nav = input_pop_nav();
        if (nav == 0 && m3_entry_len > 0) {
            m3_entry_len--;
            led_off((uint8_t)m3_secret[m3_entry_len]);
            m3_fb = -1;
            beep_click();
            m3_last_elen = -1;
        } else if (nav == 1 && m3_entry_len >= 2) {
            m3_sec_len = m3_entry_len;
            leds_off();
            beep_start();
            input_lock_game();
            input_lock_nav();
            { char b[17];
              snprintf(b, 17, "Show to P%d now ", (m3_chall == 0) ? 2 : 1);
              lcd_row(0, "Sequence set!  ");
              lcd_row(1, b); }
            m3_last_elen = -1;
            m3_tmr = now;
            m3_st  = M3_SHOW_SEQ;
        }
        break;
    }

    case M3_SHOW_SEQ:
        if ((uint32_t)(now - m3_tmr) < ANNOUNCE_MS) break;
        if (!m3_fl_started) {
            input_clear_all();
            flash_start(m3_secret, m3_sec_len, LED_ON_START);
            m3_fl_started = 1;
        }
        if (flash_run()) { m3_tmr = now; m3_st = M3_PAUSE; }
        break;

    case M3_PAUSE:
        if ((uint32_t)(now - m3_tmr) >= INPUT_GAP) {
            m3_rep_idx = 0;
            m3_btmr    = now;
            input_clear_game();
            input_unlock_game();
            { char t[17], b[17];
              snprintf(t, 17, "P%d: replicate! ", (m3_chall == 0) ? 2 : 1);
              snprintf(b, 17, "Press %d buttons ", m3_sec_len);
              lcd_row(0, t); lcd_row(1, b); }
            m3_st = M3_REPLICATE;
        }
        break;

    case M3_REPLICATE: {
        int8_t btn = rep_btn();
        if (btn >= 0) {
            led_on((uint8_t)btn); m3_fb = btn; m3_fbe = now + 200UL;
            m3_btmr = now;
            if (btn == m3_secret[m3_rep_idx]) {
                beep_ok();
                m3_rep_idx++;
                if (m3_rep_idx >= m3_sec_len) {
                    m3_rep_ok = 1;
                    input_lock_game();
                    m3_st = M3_CHECK;
                }
            } else {
                beep_fail();
                input_lock_game();
                m3_st = M3_CHECK;
            }
        } else if ((uint32_t)(now - m3_btmr) >= TIMEOUT_MS) {
            beep_over();
            input_lock_game();
            m3_st = M3_CHECK;
        }
        break;
    }

    case M3_CHECK:
        leds_off();
        if (m3_rep_ok) {
            give_pts(1 - m3_chall, CHALL_REP_WIN);
            { char t[17], b[17];
              snprintf(t, 17, "P%d REPLICATED! ", (1 - m3_chall) + 1);
              snprintf(b, 17, "+%d pts!        ", CHALL_REP_WIN);
              lcd_row(0, t); lcd_row(1, b); }
            beep_start();
            m3_tmr = now; m3_st = M3_ROUND_END;
        } else {
            { char t[17];
              snprintf(t, 17, "FAIL! P%d prove ", m3_chall + 1);
              lcd_row(0, t); lcd_row(1, "Can challenger?"); }
            m3_tmr = now; m3_st = M3_PROVE_START;
        }
        break;

    case M3_PROVE_START:
        if ((uint32_t)(now - m3_tmr) >= ANNOUNCE_MS) {
            m3_rep_idx = 0;
            m3_rep_ok  = 0;
            m3_btmr    = now;
            input_clear_game();
            input_unlock_game();
            { char t[17];
              snprintf(t, 17, "P%d: PROVE IT!  ", m3_chall + 1);
              lcd_row(0, t); lcd_row(1, "Re-enter seq   "); }
            m3_st = M3_PROVING;
        }
        break;

    case M3_PROVING: {
        int8_t btn = chall_btn();
        if (btn >= 0) {
            led_on((uint8_t)btn); m3_fb = btn; m3_fbe = now + 200UL;
            m3_btmr = now;
            if (btn == m3_secret[m3_rep_idx]) {
                beep_ok();
                m3_rep_idx++;
                if (m3_rep_idx >= m3_sec_len) {
                    m3_rep_ok = 1;
                    input_lock_game();
                    m3_st = M3_CHECK_PROVE;
                }
            } else {
                beep_fail();
                input_lock_game();
                m3_st = M3_CHECK_PROVE;
            }
        } else if ((uint32_t)(now - m3_btmr) >= TIMEOUT_MS) {
            beep_over();
            input_lock_game();
            m3_st = M3_CHECK_PROVE;
        }
        break;
    }

    case M3_CHECK_PROVE:
        leds_off();
        if (m3_rep_ok) {
            give_pts(m3_chall, CHALL_PROVE);
            { char t[17], b[17];
              snprintf(t, 17, "P%d PROVED IT!  ", m3_chall + 1);
              snprintf(b, 17, "+%d pts!        ", CHALL_PROVE);
              lcd_row(0, t); lcd_row(1, b); }
            beep_start();
        } else {
            lcd_row(0, "PROOF FAILED!  ");
            lcd_row(1, "No points.     ");
            beep_fail();
        }
        m3_tmr = now; m3_st = M3_ROUND_END;
        break;

    case M3_ROUND_END:
        if ((uint32_t)(now - m3_tmr) >= RESULT_MS) {
            m3_round++;
            if (m3_round >= CHALL_ROUNDS) {
                m3_st = M3_DONE;
            } else {
                m3_chall = 1 - m3_chall;
                m3_st    = M3_ANNOUNCE;
            }
        }
        break;

    case M3_DONE:
        leds_off();
        *s1 = m3_p1; *s2 = m3_p2;
        return 1;
    }

    return 0;
}
