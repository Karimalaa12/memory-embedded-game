#ifndef CONFIG_H
#define CONFIG_H

#ifndef F_CPU
#  define F_CPU 16000000UL
#endif

#define BTN_P1_0_BIT   PD2
#define BTN_P1_1_BIT   PD3
#define BTN_P1_2_BIT   PD4
#define BTN_P1_3_BIT   PD5

#define BTN_P2_0_BIT   PD6
#define BTN_P2_1_BIT   PD7
#define BTN_P2_2_BIT   PB2
#define BTN_P2_3_BIT   PB4

#define BTN_NAV_UP_BIT   PC0
#define BTN_NAV_SEL_BIT  PC1

#define LED0_BIT   PC2
#define LED1_BIT   PC3
#define LED2_BIT   PB0
#define LED3_BIT   PB1

#define BUZZ_BIT   PB3

#define LCD_ADDR   0x27

#define EE_MAGIC   0
#define EE_HI1     2
#define EE_HI2     4
#define MAGIC      0xA5

#define DEBOUNCE_MS       200
#define TIMEOUT_MS      8000
#define SLEEP_MS      120000UL
#define ANNOUNCE_MS     1500
#define RESULT_MS       2000
#define INPUT_GAP       1000
#define GAMEOVER_MS     2500
#define SPLASH_MS       2000
#define SCORES_CLEAR_MS 1500

#define LED_ON_START  700
#define LED_ON_MIN    200
#define LED_OFF_GAP   250

#define DIFF_STEP    50
#define DIFF_EVERY    2

#define SEQ_LEN_START   3
#define SEQ_LEN_MAX    15

#define SOLO_PTS       10
#define DUEL_PTS        5
#define DUEL_SPEED      3
#define CHALL_REP_WIN  15
#define CHALL_PROVE    10
#define MAX_SCORE     999
#define DUEL_ROUNDS     5
#define CHALL_ROUNDS    4
#define CHALL_SEQ_MAX   8

#define BUZZ_OK     30
#define BUZZ_FAIL  141
#define BUZZ_OVER  207
#define BUZZ_CLICK  19
#define BUZZ_START  35
#define DUR_SHORT   80
#define DUR_LONG   400

#define BTN_QUEUE_SIZE  8
#define BTN_QUEUE_MASK  (BTN_QUEUE_SIZE - 1)

#define MENU_SOLO     0
#define MENU_DUEL     1
#define MENU_CHALL    2
#define MENU_SCORES   3
#define MENU_COUNT    4

#define APP_SPLASH  0
#define APP_MENU    1
#define APP_SOLO    2
#define APP_DUEL    3
#define APP_CHALL   4
#define APP_SCORES  5
#define APP_WAIT    6

#endif
