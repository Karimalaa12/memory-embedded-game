#ifndef MODE1_H
#define MODE1_H

#include <stdint.h>

void    mode1_start(void);
uint8_t mode1_update(int *score1);

#endif
