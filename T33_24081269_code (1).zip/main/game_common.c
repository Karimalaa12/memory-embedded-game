#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include <stdint.h>
#include "config.h"
#include "game_common.h"

uint32_t millis(void) {
    uint32_t t;
    uint8_t  sreg = SREG;
    cli();
    t = ms_count;
    SREG = sreg;
    return t;
}

void led_on(uint8_t i) {
    switch (i) {
        case 0: PORTC |= (1 << LED0_BIT); break;
        case 1: PORTC |= (1 << LED1_BIT); break;
        case 2: PORTB |= (1 << LED2_BIT); break;
        case 3: PORTB |= (1 << LED3_BIT); break;
        default: break;
    }
}

void led_off(uint8_t i) {
    switch (i) {
        case 0: PORTC &= (uint8_t)~(1 << LED0_BIT); break;
        case 1: PORTC &= (uint8_t)~(1 << LED1_BIT); break;
        case 2: PORTB &= (uint8_t)~(1 << LED2_BIT); break;
        case 3: PORTB &= (uint8_t)~(1 << LED3_BIT); break;
        default: break;
    }
}

void leds_off(void) {
    PORTC &= (uint8_t)~((1 << LED0_BIT) | (1 << LED1_BIT));
    PORTB &= (uint8_t)~((1 << LED2_BIT) | (1 << LED3_BIT));
}

void seq_make(int *seq, int len) {
    for (int i = 0; i < len; i++) seq[i] = rand() % 4;
}

int flash_ms(int round) {
    int t = LED_ON_START - (round / DIFF_EVERY) * DIFF_STEP;
    return (t < LED_ON_MIN) ? LED_ON_MIN : t;
}

static int     fl_seq[SEQ_LEN_MAX];
static int     fl_len;
static int     fl_pos;
static uint8_t fl_phase;
static uint32_t fl_t;
static int     fl_on_ms;
static uint8_t fl_done;
static uint8_t fl_running;

void flash_start(int *seq, int len, int on_ms) {
    for (int i = 0; i < len; i++) fl_seq[i] = seq[i];
    fl_len     = len;
    fl_pos     = 0;
    fl_phase   = 0;
    fl_on_ms   = on_ms;
    fl_done    = 0;
    fl_running = 1;
    fl_t       = millis();
    leds_off();
    led_on((uint8_t)seq[0]);
}

uint8_t flash_run(void) {
    if (!fl_running || fl_done) return fl_done;
    uint32_t now = millis();

    if (fl_phase == 0) {
        if ((uint32_t)(now - fl_t) >= (uint32_t)fl_on_ms) {
            led_off((uint8_t)fl_seq[fl_pos]);
            fl_phase = 1;
            fl_t     = now;
        }
    } else {
        if ((uint32_t)(now - fl_t) >= (uint32_t)LED_OFF_GAP) {
            fl_pos++;
            if (fl_pos >= fl_len) {
                fl_done    = 1;
                fl_running = 0;
                leds_off();
                return 1;
            }
            led_on((uint8_t)fl_seq[fl_pos]);
            fl_phase = 0;
            fl_t     = now;
        }
    }
    return 0;
}
